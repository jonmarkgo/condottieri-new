lightbox-gallery created under test project, to provide gallery option in lightbox+iviewer intergation.

Using lightbox-gallery, all images that are in gallery will be grouped, so that navigation from one image to other is possible from lightbox itself.
Anchors tag of image that are to be added in gallery, shuld have attribute rel="gallery".

jQuery.iviewer is an jQuery UI widget responsible for image view control with zoom
control and a possibility to move image in area by the mouse.

Widget depends on the jquery.ui.core, jquery.ui.widget and jquery.ui.mouse.

Features:
 * Total control over the widget through API.
 * Controls can be customized with CSS.
 * Smooth zoom.

 Support: widget is expected to work in ie6+, ff2+, google chrome, opera 9+, safari.

 Demo to come soon

Widget is licensed under the MIT (http://www.opensource.org/licenses/mit-license.php) license.


Docs are available at http://wiki.github.com/can3p/iviewer
